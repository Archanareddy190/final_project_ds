# 🎲 Roll Dice Game — Java Console Application

A console-based multiplayer dice-rolling game built with core **Java Data Structures** and **File I/O**.  
This project was developed as an academic submission demonstrating real-world use of linked lists, circular queues, sorting, and persistent file storage.

---

## 📚 Data Structures & Concepts Used

| Concept | Class | Purpose |
|---|---|---|
| Singly Linked List | `PlayerLinkedList` | Store and manage players |
| Circular Queue | `CircularQueue` | Rotate player turns fairly |
| Linear Search | `Searching` | Find a player by ID |
| Comparison Sort | `Sorting` | Rank players for the leaderboard |
| **FileWriter** | `PlayerLinkedList.saveToFile()` | Persist player data to disk |
| **FileReader** | `PlayerLinkedList.loadFromFile()` | Restore player data from disk |
| Append Logging | `PlayerLinkedList.appendLog()` | Record each game session |
| OOP Design | All classes | Encapsulation, single responsibility |

---

## 🗂 Project Structure

```
RollDiceGame/
├── src/
│   └── RollDiceGame/
│       ├── Main.java              ← Entry point + menu
│       ├── Player.java            ← Player model
│       ├── Node.java              ← Linked list node
│       ├── PlayerLinkedList.java  ← Linked list + File I/O
│       ├── CircularQueue.java     ← Turn manager
│       ├── Game.java              ← Game logic + dice
│       ├── Sorting.java           ← Leaderboard sort
│       └── Searching.java         ← Linear search
├── data/
│   ├── players.txt                ← Auto-generated player save file
│   └── game_log.txt               ← Auto-generated session log
└── README.md
```

---

## 🚀 How to Run

### Prerequisites
- Java Development Kit (JDK) 8 or higher
- A terminal / command prompt

### Compile

```bash
# From the project root
javac -d out src/RollDiceGame/*.java
```

### Run

```bash
java -cp out RollDiceGame.Main
```

### One-liner (compile + run)

```bash
javac -d out src/RollDiceGame/*.java && java -cp out RollDiceGame.Main
```

> **Windows users:** replace `/` with `\` in paths if needed.

---

## 🎮 Menu Options

```
1.  Add Player             — Register a new player (auto-saves)
2.  Play Game              — Start a game with N rounds
3.  Leaderboard            — View sorted scores
4.  Search Player by ID    — Linear search through the list
5.  Delete Player          — Remove a player by ID (auto-saves)
6.  Display All Players    — List the entire roster
7.  Save Players to File   — Manually save to data/players.txt
8.  Load Players from File — Manually load from data/players.txt
9.  View Game Log          — Print session history from data/game_log.txt
10. Exit                   — Save and quit
```

---

## 💾 File I/O Details

### `data/players.txt`  (FileWriter / FileReader)
```
# RollDiceGame — Player Data
# Format: id,name,score
# NextID:1004
1001,Alice,18
1002,Bob,12
1003,Charlie,25
```

### `data/game_log.txt`  (FileWriter — append mode)
```
[Session: 2025-06-01 14:32:11] | Players: 3 | Rounds: 3
[Session: 2025-06-01 15:00:45] | Players: 2 | Rounds: 5
```

---

## 🛠 File I/O API Summary

| Method | I/O Class | Description |
|---|---|---|
| `saveToFile(path)` | `FileWriter` + `BufferedWriter` | Write all players to CSV |
| `loadFromFile(path)` | `FileReader` + `BufferedReader` | Read and restore players |
| `appendLog(path, entry)` | `FileWriter(append=true)` | Append a log line |
| `readLog(path)` | `FileReader` + `BufferedReader` | Print the full log |

---

## 👥 Author

Submitted to the **Head of Department (HOD)**  
Department of Computer Science / Information Technology  

---

## 📄 License

This project is for academic purposes.
