@echo off
REM ─────────────────────────────────────────────────────
REM  Roll Dice Game — Build & Run Script (Windows)
REM ─────────────────────────────────────────────────────

echo.
echo   Roll Dice Game - Build Script
echo   --------------------------------

REM Create output directories
if not exist out mkdir out
if not exist data mkdir data

REM Compile all Java source files
echo   Compiling sources...
javac -d out src\RollDiceGame\*.java

if %errorlevel% neq 0 (
    echo.
    echo   Compilation failed. Please check errors above.
    pause
    exit /b 1
)

echo   Compilation successful.
echo.

REM Run the application
java -cp out RollDiceGame.Main

pause
