#!/bin/bash
# ─────────────────────────────────────────────────────
#  Roll Dice Game — Build & Run Script (Linux / macOS)
# ─────────────────────────────────────────────────────

echo ""
echo "  🎲  Roll Dice Game — Build Script"
echo "  ──────────────────────────────────"

# 1. Create output directory
mkdir -p out data

# 2. Compile all Java source files
echo "  Compiling sources..."
javac -d out src/RollDiceGame/*.java

if [ $? -ne 0 ]; then
  echo ""
  echo "  ✘ Compilation failed. Please check errors above."
  exit 1
fi

echo "  ✔ Compilation successful."
echo ""

# 3. Run the application
java -cp out RollDiceGame.Main
