package RollDiceGame;

/**
 * A circular queue (ring buffer) used to manage player turns during a game.
 *
 * <p>Players are enqueued once before a game begins. On each call to
 * {@link #nextTurn()}, the front player is returned and re-enqueued at the
 * rear, so the queue cycles indefinitely through all players.
 */
public class CircularQueue {

    private Player[] queue;
    private int front   = 0;
    private int rear    = -1;
    private int size    = 0;
    private final int capacity;

    /**
     * Constructs a CircularQueue with the given fixed capacity.
     *
     * @param capacity Maximum number of players the queue can hold
     */
    public CircularQueue(int capacity) {
        this.capacity = capacity;
        this.queue    = new Player[capacity];
    }

    /**
     * Adds a player to the rear of the circular queue.
     *
     * @param p The Player to enqueue
     */
    public void add(Player p) {
        rear        = (rear + 1) % capacity;
        queue[rear] = p;
        size++;
    }

    /**
     * Returns the player whose turn it is (front of the queue) and
     * immediately re-enqueues them at the rear so the cycle continues.
     *
     * @return The next Player in the rotation
     */
    public Player nextTurn() {
        Player p = queue[front];
        front    = (front + 1) % capacity;

        // Re-enqueue at rear to keep the cycle going
        rear        = (rear + 1) % capacity;
        queue[rear] = p;

        return p;
    }

    /**
     * Returns the current number of distinct players in the queue.
     *
     * @return Queue size
     */
    public int size() {
        return size;
    }
}
