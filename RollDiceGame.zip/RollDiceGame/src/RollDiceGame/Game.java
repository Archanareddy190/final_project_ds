package RollDiceGame;

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Manages game logic for the Dice Roll Game.
 *
 * <p>A game consists of multiple rounds.  In each round every player in the
 * {@link CircularQueue} is given the option to roll a six-sided die.  Rolling
 * adds the result to the player's cumulative score.  After all rounds finish,
 * the session result is appended to the game log file via
 * {@link PlayerLinkedList#appendLog}.
 */
public class Game {

    private final Random rand = new Random();
    private final Scanner sc  = new Scanner(System.in);

    // Path to the persistent game-log file
    static final String LOG_FILE = "data/game_log.txt";

    // ─────────────────────────────────────────────────────────────
    //  Dice
    // ─────────────────────────────────────────────────────────────

    /**
     * Simulates rolling a fair six-sided die.
     *
     * @return A random integer in the range [1, 6]
     */
    public int rollDice() {
        return rand.nextInt(6) + 1;
    }

    // ─────────────────────────────────────────────────────────────
    //  Game Rounds
    // ─────────────────────────────────────────────────────────────

    /**
     * Runs the specified number of game rounds using the provided
     * {@link CircularQueue} of players.
     *
     * <p>After every round each player is shown their current score.
     * When all rounds have finished, a summary is logged to disk via
     * {@link PlayerLinkedList#appendLog(String, String)}.
     *
     * @param cq           CircularQueue containing participating players
     * @param rounds       Number of rounds to play
     * @param totalPlayers Number of distinct players in the queue
     */
    public void playRounds(CircularQueue cq, int rounds, int totalPlayers) {
        System.out.println("\n  ══════════════════════════════════");
        System.out.println("   🎲  GAME STARTED  (" + rounds + " rounds)  🎲");
        System.out.println("  ══════════════════════════════════");

        StringBuilder sessionLog = new StringBuilder();
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        sessionLog.append("[Session: ").append(timestamp).append("]");

        for (int i = 1; i <= rounds; i++) {
            System.out.println("\n  ── Round " + i + " of " + rounds + " ──");

            for (int j = 0; j < totalPlayers; j++) {
                Player p = cq.nextTurn();

                System.out.print("  " + p.name + "  →  Roll? (1) Yes  (2) Skip : ");
                int choice;
                try {
                    choice = sc.nextInt();
                } catch (InputMismatchException e) {
                    sc.nextLine(); // flush bad input
                    choice = 2;
                }

                if (choice == 1) {
                    int result = rollDice();
                    p.score += result;
                    System.out.println("  🎲 Rolled " + result
                            + "  →  Total score: " + p.score);
                } else {
                    System.out.println("  ⏭ " + p.name + " skipped.");
                }
            }
        }

        System.out.println("\n  ✅ Game finished! Check the leaderboard.");

        // Build and persist the log entry
        sessionLog.append(" | Players: ").append(totalPlayers)
                  .append(" | Rounds: ").append(rounds);
        PlayerLinkedList.appendLog(LOG_FILE, sessionLog.toString());
    }
}
