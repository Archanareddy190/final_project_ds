package RollDiceGame;

import java.util.*;

/**
 * <h1>Roll Dice Game — Main Entry Point</h1>
 *
 * <p>This is a console-based multiplayer dice game that demonstrates the
 * use of core Java Data Structures and File I/O:
 *
 * <ul>
 *   <li><b>Singly Linked List</b>  — {@link PlayerLinkedList} manages players</li>
 *   <li><b>Circular Queue</b>      — {@link CircularQueue} handles player turns</li>
 *   <li><b>Linear Search</b>       — {@link Searching} locates a player by ID</li>
 *   <li><b>Comparison Sort</b>     — {@link Sorting} renders the leaderboard</li>
 *   <li><b>FileWriter</b>          — {@link PlayerLinkedList#saveToFile} persists data</li>
 *   <li><b>FileReader</b>          — {@link PlayerLinkedList#loadFromFile} restores data</li>
 *   <li><b>Append Logging</b>      — {@link PlayerLinkedList#appendLog} writes game logs</li>
 * </ul>
 *
 * <p><b>Data files</b> are stored in the {@code data/} directory:
 * <ul>
 *   <li>{@code data/players.txt}  — player roster (CSV)</li>
 *   <li>{@code data/game_log.txt} — session history</li>
 * </ul>
 *
 * @author  RollDiceGame Team
 * @version 2.0
 */
public class Main {

    /** Path for the persistent player-roster file. */
    static final String SAVE_FILE = "data/players.txt";

    // ─────────────────────────────────────────────────────────────
    //  Entry Point
    // ─────────────────────────────────────────────────────────────

    public static void main(String[] args) {

        Scanner sc             = new Scanner(System.in);
        PlayerLinkedList list  = new PlayerLinkedList();
        Game game              = new Game();

        printBanner();

        // Auto-load any previously saved player data
        System.out.println("\n  Loading saved player data...");
        list.loadFromFile(SAVE_FILE);

        // ── Main Menu Loop ───────────────────────────────────────
        while (true) {
            printMenu();

            int choice = readInt(sc);

            switch (choice) {

                // ── 1. Add Player ──────────────────────────────
                case 1:
                    System.out.print("\n  Enter player name: ");
                    String name = sc.next();
                    list.addPlayer(name);
                    list.saveToFile(SAVE_FILE);   // auto-save after each change
                    break;

                // ── 2. Play Game ───────────────────────────────
                case 2:
                    int count = list.count();
                    if (count < 1) {
                        System.out.println("  ⚠ Add at least one player before playing.");
                        break;
                    }

                    System.out.print("  Enter number of rounds (default 3): ");
                    int rounds = readInt(sc);
                    if (rounds <= 0) rounds = 3;

                    CircularQueue cq = new CircularQueue(count);
                    Node temp = list.head;
                    while (temp != null) {
                        cq.add(temp.data);
                        temp = temp.next;
                    }

                    game.playRounds(cq, rounds, count);
                    list.saveToFile(SAVE_FILE);   // persist updated scores
                    break;

                // ── 3. Leaderboard ─────────────────────────────
                case 3:
                    Sorting.showLeaderboard(list.head);
                    break;

                // ── 4. Search Player ───────────────────────────
                case 4:
                    System.out.print("\n  Enter Player ID to search: ");
                    int searchId = readInt(sc);
                    Searching.search(list.head, searchId);
                    break;

                // ── 5. Delete Player ───────────────────────────
                case 5:
                    System.out.print("\n  Enter Player ID to delete: ");
                    int deleteId = readInt(sc);
                    list.deletePlayer(deleteId);
                    list.saveToFile(SAVE_FILE);   // auto-save after deletion
                    break;

                // ── 6. Display All Players ─────────────────────
                case 6:
                    System.out.println("\n  ── All Registered Players ──");
                    list.displayAll();
                    break;

                // ── 7. Save Players to File ────────────────────
                case 7:
                    list.saveToFile(SAVE_FILE);
                    break;

                // ── 8. Load Players from File ──────────────────
                case 8:
                    list.loadFromFile(SAVE_FILE);
                    break;

                // ── 9. View Game Log ───────────────────────────
                case 9:
                    PlayerLinkedList.readLog(Game.LOG_FILE);
                    break;

                // ── 10. Exit ───────────────────────────────────
                case 10:
                    System.out.println("\n  Saving data before exit...");
                    list.saveToFile(SAVE_FILE);
                    System.out.println("  👋 Thanks for playing! Goodbye.\n");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("  ✘ Invalid choice. Please enter 1–10.");
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  UI Helpers
    // ─────────────────────────────────────────────────────────────

    /** Prints the welcome banner. */
    private static void printBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║                                          ║");
        System.out.println("  ║       🎲  ROLL DICE GAME  v2.0  🎲       ║");
        System.out.println("  ║   Linked List + Queue + File I/O Demo   ║");
        System.out.println("  ║                                          ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
    }

    /** Prints the main menu. */
    private static void printMenu() {
        System.out.println();
        System.out.println("  ┌─────────────────────────────┐");
        System.out.println("  │         MAIN  MENU          │");
        System.out.println("  ├─────────────────────────────┤");
        System.out.println("  │  1.  Add Player             │");
        System.out.println("  │  2.  Play Game              │");
        System.out.println("  │  3.  Leaderboard            │");
        System.out.println("  │  4.  Search Player by ID    │");
        System.out.println("  │  5.  Delete Player          │");
        System.out.println("  │  6.  Display All Players    │");
        System.out.println("  │  7.  Save Players to File   │");
        System.out.println("  │  8.  Load Players from File │");
        System.out.println("  │  9.  View Game Log          │");
        System.out.println("  │  10. Exit                   │");
        System.out.println("  └─────────────────────────────┘");
        System.out.print("  Choice: ");
    }

    /**
     * Safely reads an integer from the scanner, returning -1 on bad input.
     *
     * @param sc The Scanner to read from
     * @return Parsed integer, or -1 if input is not a number
     */
    private static int readInt(Scanner sc) {
        try {
            int v = sc.nextInt();
            sc.nextLine(); // consume leftover newline
            return v;
        } catch (InputMismatchException e) {
            sc.nextLine(); // flush bad input
            return -1;
        }
    }
}
