package RollDiceGame;

/**
 * Represents a node in the singly linked list of players.
 */
public class Node {
    Player data;
    Node next;

    /**
     * Constructs a Node wrapping the given Player.
     * @param data The Player object to store
     */
    public Node(Player data) {
        this.data = data;
        this.next = null;
    }
}
