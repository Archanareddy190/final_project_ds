package RollDiceGame;

/**
 * Represents a player in the Dice Roll Game.
 * Stores player ID, name, and current score.
 */
public class Player {
    int id;
    String name;
    int score;

    /**
     * Constructs a new Player with the given ID and name.
     * @param id   Unique player identifier
     * @param name Player's display name
     */
    public Player(int id, String name) {
        this.id = id;
        this.name = name;
        this.score = 0;
    }

    /**
     * Returns a formatted string representation of the player.
     */
    @Override
    public String toString() {
        return id + "," + name + "," + score;
    }

    /**
     * Returns a display-friendly string for leaderboard output.
     */
    public String toDisplayString() {
        return String.format("%-6d %-15s %d", id, name, score);
    }
}
