package RollDiceGame;

import java.io.*;
import java.util.*;

/**
 * A singly linked list that manages Player nodes.
 *
 * <p>Supports persistent storage via FileReader and FileWriter:
 * <ul>
 *   <li>{@link #saveToFile(String)} — serialises all players to CSV</li>
 *   <li>{@link #loadFromFile(String)} — deserialises players from CSV</li>
 * </ul>
 *
 * <p>Data file format (one player per line):
 * <pre>id,name,score</pre>
 */
public class PlayerLinkedList {

    Node head;
    static int counter = 1001;

    // ─────────────────────────────────────────────────────────────
    //  Core Linked-List Operations
    // ─────────────────────────────────────────────────────────────

    /**
     * Appends a new player with the given name to the end of the list.
     * The player is assigned a unique, auto-incremented ID.
     *
     * @param name The name of the player to add
     */
    public void addPlayer(String name) {
        Player p = new Player(counter++, name);
        Node n = new Node(p);

        if (head == null) {
            head = n;
        } else {
            Node t = head;
            while (t.next != null) t = t.next;
            t.next = n;
        }
        System.out.println("  ✔ Player \"" + name + "\" added with ID " + p.id);
    }

    /**
     * Deletes the player with the specified ID from the list.
     * Prints a confirmation or a "not found" message.
     *
     * @param id The unique ID of the player to remove
     */
    public void deletePlayer(int id) {
        Node t = head, prev = null;

        while (t != null && t.data.id != id) {
            prev = t;
            t = t.next;
        }

        if (t == null) {
            System.out.println("  ✘ Player with ID " + id + " not found.");
            return;
        }

        if (prev == null) head = head.next;
        else prev.next = t.next;

        System.out.println("  ✔ Player \"" + t.data.name + "\" (ID " + id + ") deleted.");
    }

    /**
     * Returns the total number of players currently in the list.
     *
     * @return Count of players
     */
    public int count() {
        int c = 0;
        Node t = head;
        while (t != null) { c++; t = t.next; }
        return c;
    }

    /**
     * Prints every player currently in the list.
     */
    public void displayAll() {
        if (head == null) {
            System.out.println("  (No players registered)");
            return;
        }
        System.out.println(String.format("  %-6s %-15s %s", "ID", "NAME", "SCORE"));
        System.out.println("  " + "-".repeat(30));
        Node t = head;
        while (t != null) {
            System.out.println("  " + t.data.toDisplayString());
            t = t.next;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  File I/O  —  FileWriter (Save) & FileReader (Load)
    // ─────────────────────────────────────────────────────────────

    /**
     * Persists all players in the list to a CSV file using {@link FileWriter}.
     *
     * <p>Each line in the file has the format: {@code id,name,score}
     * A header comment is written on the first line for human readability.
     *
     * @param filePath Path of the destination file (e.g. {@code "data/players.txt"})
     */
    public void saveToFile(String filePath) {
        // Ensure parent directories exist
        File file = new File(filePath);
        if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
        }

        try (FileWriter fw = new FileWriter(filePath);
             BufferedWriter bw = new BufferedWriter(fw)) {

            // Write a human-readable header
            bw.write("# RollDiceGame — Player Data");
            bw.newLine();
            bw.write("# Format: id,name,score");
            bw.newLine();
            bw.write("# NextID:" + counter);
            bw.newLine();

            // Traverse the list and write each player
            Node t = head;
            int written = 0;
            while (t != null) {
                bw.write(t.data.toString());   // "id,name,score"
                bw.newLine();
                t = t.next;
                written++;
            }

            System.out.println("  ✔ Saved " + written + " player(s) to \"" + filePath + "\"");

        } catch (IOException e) {
            System.out.println("  ✘ Save failed: " + e.getMessage());
        }
    }

    /**
     * Loads players from a CSV file into the linked list using {@link FileReader}.
     *
     * <p>Lines beginning with {@code #} are treated as comments and ignored.
     * Malformed lines are skipped with a warning. The ID counter is restored
     * from the file so new players never collide with loaded ones.
     *
     * @param filePath Path of the source file (e.g. {@code "data/players.txt"})
     */
    public void loadFromFile(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("  ℹ No save file found at \"" + filePath + "\". Starting fresh.");
            return;
        }

        // Clear the current list before loading
        head = null;
        int loaded = 0;

        try (FileReader fr = new FileReader(filePath);
             BufferedReader br = new BufferedReader(fr)) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();

                // Skip blank lines and standard comment lines
                if (line.isEmpty() || line.startsWith("#")) {
                    // Restore the counter from the special metadata comment
                    if (line.startsWith("# NextID:")) {
                        try {
                            counter = Integer.parseInt(line.split(":")[1].trim());
                        } catch (NumberFormatException ignored) { }
                    }
                    continue;
                }

                // Parse "id,name,score"
                String[] parts = line.split(",", 3);
                if (parts.length < 3) {
                    System.out.println("  ⚠ Skipping malformed line: " + line);
                    continue;
                }

                try {
                    int id    = Integer.parseInt(parts[0].trim());
                    String nm = parts[1].trim();
                    int sc    = Integer.parseInt(parts[2].trim());

                    // Rebuild the player and append directly (bypass auto-ID)
                    Player p = new Player(id, nm);
                    p.score  = sc;
                    Node n   = new Node(p);

                    if (head == null) {
                        head = n;
                    } else {
                        Node tail = head;
                        while (tail.next != null) tail = tail.next;
                        tail.next = n;
                    }
                    loaded++;

                } catch (NumberFormatException e) {
                    System.out.println("  ⚠ Skipping line with invalid number: " + line);
                }
            }

            System.out.println("  ✔ Loaded " + loaded + " player(s) from \"" + filePath + "\"");

        } catch (IOException e) {
            System.out.println("  ✘ Load failed: " + e.getMessage());
        }
    }

    /**
     * Appends a single game-result log entry to a log file using {@link FileWriter}
     * in append mode.  Called after every completed game round.
     *
     * @param filePath  Path of the log file (e.g. {@code "data/game_log.txt"})
     * @param logEntry  The line of text to append
     */
    public static void appendLog(String filePath, String logEntry) {
        File file = new File(filePath);
        if (file.getParentFile() != null) file.getParentFile().mkdirs();

        // true = append mode; existing content is preserved
        try (FileWriter fw = new FileWriter(filePath, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(logEntry);
            bw.newLine();

        } catch (IOException e) {
            System.out.println("  ⚠ Log write failed: " + e.getMessage());
        }
    }

    /**
     * Reads and prints the full contents of the game log file
     * using {@link FileReader}.
     *
     * @param filePath Path of the log file
     */
    public static void readLog(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("  ℹ No game log found at \"" + filePath + "\".");
            return;
        }

        System.out.println("\n  ── Game Log (" + filePath + ") ──");
        try (FileReader fr = new FileReader(filePath);
             BufferedReader br = new BufferedReader(fr)) {

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("  " + line);
            }

        } catch (IOException e) {
            System.out.println("  ✘ Log read failed: " + e.getMessage());
        }
    }
}
