package RollDiceGame;

/**
 * Provides linear-search utilities for the player linked list.
 */
public class Searching {

    /**
     * Performs a linear search through the linked list to find a player
     * by their unique ID, then prints their details.
     *
     * <p>Time complexity: O(n)
     *
     * @param head The head node of the player linked list
     * @param id   The player ID to search for
     */
    public static void search(Node head, int id) {
        while (head != null) {
            if (head.data.id == id) {
                System.out.println("\n  ── Player Found ──");
                System.out.printf("  ID    : %d%n", head.data.id);
                System.out.printf("  Name  : %s%n", head.data.name);
                System.out.printf("  Score : %d%n", head.data.score);
                return;
            }
            head = head.next;
        }
        System.out.println("  ✘ Player with ID " + id + " not found.");
    }
}
