package RollDiceGame;

import java.util.*;

/**
 * Provides sorting utilities for the game leaderboard.
 *
 * <p>Uses the built-in {@link ArrayList#sort} with a lambda comparator to
 * order players by score in descending order (highest scorer first).
 */
public class Sorting {

    /**
     * Collects all players from the linked list into an {@link ArrayList},
     * sorts them by score (descending), and prints a formatted leaderboard.
     *
     * @param head The head node of the player linked list
     */
    public static void showLeaderboard(Node head) {
        ArrayList<Player> list = new ArrayList<>();

        // Traverse the linked list and collect all players
        while (head != null) {
            list.add(head.data);
            head = head.next;
        }

        if (list.isEmpty()) {
            System.out.println("  (No players to display)");
            return;
        }

        // Sort descending by score using a lambda comparator
        list.sort((a, b) -> b.score - a.score);

        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║           🏆  LEADERBOARD  🏆         ║");
        System.out.println("  ╠══════════════════════════════════════╣");
        System.out.printf("  ║  %-4s  %-6s  %-12s  %-6s  ║%n", "RANK", "ID", "NAME", "SCORE");
        System.out.println("  ╠══════════════════════════════════════╣");

        String[] medals = {"🥇", "🥈", "🥉"};
        for (int i = 0; i < list.size(); i++) {
            Player p    = list.get(i);
            String rank = (i < 3) ? medals[i] : ("  " + (i + 1));
            System.out.printf("  ║  %-4s  %-6d  %-12s  %-6d  ║%n",
                    rank, p.id, p.name, p.score);
        }
        System.out.println("  ╚══════════════════════════════════════╝");
    }
}
